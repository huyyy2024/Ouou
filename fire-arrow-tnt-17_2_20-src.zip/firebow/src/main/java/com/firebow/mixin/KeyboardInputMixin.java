package com.firebow.mixin;

import com.firebow.util.RotationUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Khi silent đang active, xoay input theo Δ = realYaw − silentYaw để hướng đi
 * theo phím vẫn khớp camera thật. Làm tròn về −1/0/1 giống input phím (xấp xỉ).
 */
@Environment(EnvType.CLIENT)
@Mixin(KeyboardInput.class)
public class KeyboardInputMixin {

    @Inject(method = "tick", at = @At("TAIL"))
    private void firebow$fixInput(CallbackInfo ci) {
        if (!RotationUtil.isActive()) return;

        Input self = (Input) (Object) this;
        float f = self.movementForward;
        float s = self.movementSideways;
        if (f == 0 && s == 0) return;

        double a  = Math.toRadians(RotationUtil.realYaw() - RotationUtil.silentYaw());
        double c  = Math.cos(a);
        double sn = Math.sin(a);

        // cùng quy ước với movementInputToVelocity: (sideways, forward)
        double ns = s * c - f * sn;
        double nf = f * c + s * sn;

        self.movementSideways = (float) Math.round(ns);
        self.movementForward  = (float) Math.round(nf);
    }
}
